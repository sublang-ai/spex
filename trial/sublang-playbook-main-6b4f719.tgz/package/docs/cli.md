<!-- SPDX-License-Identifier: Apache-2.0 -->
<!-- SPDX-FileCopyrightText: 2026 SubLang International <https://sublang.ai> -->

# Using the CLI

`playbook` has two presentations of one configured Captain session: an
interactive tmux-play UI and a headless `playbook run` turn for scripts and
CI. Both use the same compiled Captain, enabled catalog, players, nested
stack, and [config](configuration.md); only presentation differs.

The interactive form requires tmux 3.3 or newer and `glow` on `PATH`;
the headless form requires neither presentation tool.

## Installing agent SDKs

Installing `@sublang/playbook` automatically acquires both Claude Agent SDK
and Codex SDK through its ordinary Cligent dependency. Authenticate the selected
backend separately; SDK availability does not prove provider access.
Cligent owns their supported floors, tested targets, physical runtime lookup
and dependency diagnostics.

```sh
npm install -g @sublang/playbook
# Only when selecting optional OpenCode:
npm install -g @opencode-ai/sdk opencode-ai
```

The Gemini transport ships with Cligent but needs its supported native CLI on
`PATH`. Optional backends retain their own setup. A damaged installed SDK or
native component must be repaired in the dependency tree that the selected
Cligent package actually resolves; an unrelated sibling SDK cannot replace a
nearer damaged package. Follow the reported installation-specific repair.
Both front ends refuse unavailable or unsupported selected runtimes before
business execution, with installed/required identity where available.

## Register a local workflow

```sh
playbook add "./orders and reports/flow.mjs" --agent codex --model gpt-6.2-sol
playbook --list
playbook run "/flow /absolute/path/to/orders.csv"
```

Run `playbook add` with the JavaScript entry emitted by SLC. A relative path
is resolved from the current directory and saved as an absolute path in the
[primary config](configuration.md). The workflow supplies its own id,
command, and role ids. Each role gets a dedicated player.

`--agent` and `--model` configure the new workflow's dedicated Captain and each of its execution roles. A fresh `playbook run "/flow …"` uses that Captain for the session, including review of the results, and uses those role bindings for `flow`. The existing shared Captain, players, and other workflows are preserved.
Registration validates the catalog without launching a workflow or calling
a model. Agent login and SDK readiness are checked when starting a run. Repeating the same registration reports that it already exists.
Conflicts and invalid entries leave the config unchanged.
If the selected workflow succeeds with a single printable text result, the
reply includes that result on its own line. Provider errors during the run
report the adapter's reason on stderr.

## Interactive

```sh
playbook                         # fresh durable session in this directory
playbook --cwd /path/to/repo     # fresh session in an explicit directory
playbook --session <id>          # reopen either front end's settled session
playbook --list                  # ids, slash commands, and intents; no launch
playbook --help                  # config path, auth pointers, binding recipe
```

Without a global install, the same included Claude/Codex dependency closure
is available to a single-package invocation:

```sh
npx -y @sublang/playbook
```

An optional SDK must be reachable from that invocation's Cligent tree. For
OpenCode, name its SDK in the same npx package set; an unrelated global SDK is
not a substitute for that ephemeral tree.

For a managed launch, the outer command resolves current config (seeding it on
first use), prepares the complete stored catalog and presenter, waits for the
pane child to acquire the session lease and publish its settled turn-zero
record, prints the verified session ID, and then attaches. A normal outer
detach exits `0`; the pane child keeps owning the durable session and accepting
turns until it shuts down. Preparation, attachment, or required cleanup
failure prints its diagnostics and exits nonzero.

Before native-client hand-off, SIGHUP, SIGINT, or SIGTERM aborts activation,
joins the child, retires the lease, and only then re-raises the signal. At the
synchronous native-client hand-off, ownership transfers before tmux starts, so
later signals use native client detach or termination semantics and do not
retire the pane child's session. Only `--config` and composed
`--theme-diagnostics` use the stock subprocess boundary: those forms mirror
its exit status or signal and exit `127` when it cannot be spawned
([[playbook-cli-1](https://github.com/sublang-ai/playbook/blob/main/specs/packages/playbook-cli.md#playbook-cli-1)],
[[playbook-cli-2](https://github.com/sublang-ai/playbook/blob/main/specs/packages/playbook-cli.md#playbook-cli-2)]).

### Running a Boss turn

The Boss pane starts at the Playbook Captain shell, where the session
Captain runs for the whole session and sees every turn. Use `/code`,
`/review`, `/decide`, `/dev`, `/branch`, or `/pr` followed by a task to
select one of the bundled playbooks explicitly. A registered command resolves deterministically,
with no model call parsing it: at idle it starts that playbook, at its
own leaf it delivers the rest of the line, an enabled command absent
from the active path switches to it, and a bare command answers with
status or a clarification instead of restarting anything. Type ordinary
text and the session Captain decides the turn instead: it chats back,
starts or switches a playbook, hands the text to the working playbook,
dismisses it, or applies one recovery action the running playbook
currently offers. It never does the specialized work itself, and a
conversational turn — including a progress or status question — leaves
the engagement, its parked state, and any pending player question
untouched
([[playbook-captain-1](https://github.com/sublang-ai/playbook/blob/main/specs/packages/playbook-captain.md#playbook-captain-1)],
[[playbook-captain-2](https://github.com/sublang-ai/playbook/blob/main/specs/packages/playbook-captain.md#playbook-captain-2)]).

The current CODE, REVIEW, DECIDE, DEV, BRANCH, and PR workflows take their
deterministic initial event from the selecting Boss turn. CODE and DECIDE then
call REVIEW as a nested playbook, while DEV — the repository-aware planner
behind `/dev` — chooses the development path for a request and itself calls
CODE, or DECIDE and then CODE, as nested playbooks. When the request names a
GitHub issue or asks for pull-request delivery, DEV reads the issue and its
comments while planning, calls BRANCH before that path and PR after CODE
succeeds, and ends with a merged pull request and a closed issue — or with a
named failure that leaves the pull request open for a later `/pr`. Both are
usable on their own: `/branch <issue or request>` creates and checks out
`issue-N-slug` (or a request slug) at the current commit, changing nothing
else; `/pr` pushes the checked-out branch, opens or reuses its pull request
against the default branch, waits for the checks, fixes red checks through one
nested CODE call, merges with a merge commit, and fast-forwards the local
default branch. A repository without checks merges on CODE's nested review
alone. BRANCH, PR, and issue-aware DEV planning require the GitHub CLI `gh`,
authenticated for the repository's GitHub remote
([DR-050](https://github.com/sublang-ai/playbook/blob/main/specs/decisions/050-pull-request-delivery.md)).
Local role names do not imply continuity: each frame
uses the exact stable player IDs configured under its `roles` map. Equal IDs
share one pane and provider conversation across nested and later root
engagements; distinct IDs remain isolated even when their agent settings are
identical. When a player surfaces a
clarifying question, the playbook pauses and Captain explains the complete question briefly.
Answer or ask for clarification through Captain; reading a player pane is unnecessary.
A request to explain preserves the pending question, while an answer or explicit player follow-up reaches the waiting player
([[playbook-runtime-2](https://github.com/sublang-ai/playbook/blob/main/specs/packages/playbook-runtime.md#playbook-runtime-2)]).

The Captain pane shows start/stop/finished status with `◇` lines and
streams progress; Captain relays pending questions in its reply
([[playbook-runtime-3](https://github.com/sublang-ai/playbook/blob/main/specs/packages/playbook-runtime.md#playbook-runtime-3)]), while player
prompts ride their own panes. A turn that actually did something ends
with one Captain reply summarizing what changed, grounded in that turn's reported outcome and current pending questions; a turn that changed nothing ends with an
ordinary reply and no saved-counts line
([[playbook-captain-19](https://github.com/sublang-ai/playbook/blob/main/specs/packages/playbook-captain.md#playbook-captain-19)]).

## Headless

`playbook run [input]` submits one exact Boss turn to the same Captain that
the interactive pane hosts, without constructing tmux. The shared config
selects the Captain, enabled playbooks, players, options, provisioning, and
readiness; a slash command selects a playbook through Captain, and ordinary
text remains a conversational Captain turn.

```sh
cd ./my-repo
playbook run "/review review the latest commit"
playbook run "/code implement the approved specification"
printf '%s\n' 'Summarize the current work and propose the next step.' | playbook run
```

When `[input]` is absent, stdin is read to EOF as verbatim UTF-8 text.
Use `--` before one flag-shaped input. Plain stdout is exactly the one
Boss-visible Captain reply plus a line feed; status and diagnostics use
stderr, and `--verbose` adds only telemetry topic names to stderr.
`--json` instead prints exactly `{"sessionId":"…","reply":"…"}`.

| Flag | Meaning |
| --- | --- |
| `--with <path>` | overlay current config for a fresh session or compatible ordinary reopen; repeatable |
| `--module <id>=<specifier>` | supply playbook `<id>`'s registry module ahead of its `playbooks.<id>.from`; repeatable, one per id; a relative path resolves against the current directory |
| `--no-provision` | do not create missing engine links for configured filesystem registries |
| `--json` | print exactly one `sessionId` / `reply` object |
| `--verbose` | add Captain telemetry topic names to stderr |
| `--continue` | continue the newest Captain session stored for this working directory, or the reported global fallback |
| `--session <id>` | continue one durable Captain session explicitly |
| `--retry-uncertain` | with `--session`, restore and report interrupted work; then choose a continuation |
| `--discard-uncertain` | with `--session`, discard an attempt only if no work was recorded |
| `--` | end options before one literal input or reply |
| `-h`, `--help` | print the complete grammar without reading stdin or config |

Exit `0` means the Captain turn and its durable hand-off were presented,
even when the selected action reported rejection or failure through the
Captain reply. Argument, config, catalog, readiness, or pre-turn setup errors
exit `1`; a started-turn, persistence, lease-release, or presentation failure
exits `2` with stdout empty. SIGINT, SIGTERM, and SIGHUP withhold stdout, preserve uncertainty unless stopped recovery can save its current work, and are re-raised after lease retirement
([[playbook-cli-18](https://github.com/sublang-ai/playbook/blob/main/specs/packages/playbook-cli.md#playbook-cli-18)]).

The former positional `<from>`, `resume`, `--player`, `--captain`,
`--option`, `--cwd`, `--last`, run-only `--config`, and top-level `run:`
config are removed from `playbook run`. Enable a registry under `playbooks`,
declare provider agents once under top-level `players`, bind every local role
under `playbooks.<id>.roles`, tune compatible model, effort, fast mode,
subagent model, and subagent effort in a `--with` overlay, invoke the effective `/command`, and run from the working directory
you want agents to use. Legacy `playbooks.<id>.players` blocks are rejected and
are not auto-migrated because choosing equal or distinct new player IDs chooses
conversation sharing or isolation; see [Migrating per-playbook
players](configuration.md#migrating-per-playbook-players).

### Piping a Spex update prompt

`spex scaffold --update` refreshes its scaffold before printing guidance and
a fenced reconciliation prompt. Force Spex's non-interactive agent-file
selection, capture its successful output, extract the first fenced prompt,
and pass only that prompt to Captain:

```sh
update_output="$(spex scaffold --update </dev/null)" &&
printf '%s\n' "$update_output" |
  awk '/^```$/{if (++n==2) exit; next} n==1' |
  playbook run
```

The capture prevents a failed Spex command from launching Playbook. Without
`--lang`, the first fenced block is the sole structure reconciliation or
legacy-migration prompt; a language switch adds a second translation prompt.

### External playbooks and engine provisioning

Enable an external registry in the shared config and invoke its effective
slash command; a path-shaped `playbooks.<id>.from` is resolved relative to
the primary config file. Before either front end imports a configured
filesystem registry, the shared launcher checks whether that module can
resolve `xstate` and `@sublang/playbook/xstate-runtime`. When needed, it
creates engine symlinks beside the module and prints one provisioning line
([[playbook-cli-36](https://github.com/sublang-ai/playbook/blob/main/specs/packages/playbook-cli.md#playbook-cli-36)],
[DR-024](https://github.com/sublang-ai/playbook/blob/main/specs/decisions/024-runtime-engine-provisioning.md)).

A directory where both imports already resolve is untouched, and
`--no-provision` disables new links for either fresh front end. If the
module's directory is a git repository, add `node_modules/` to its
`.gitignore` so provisioned links never enter player commits.

A launch can also supply a playbook's module, which is never written back to
your config files, for example when an embedding host keeps each playbook
installed in an environment of its own. `--module <id>=<specifier>` (or
`--module=<id>=<specifier>`) is accepted by `playbook`, `playbook --session`,
`--list`, `--theme-diagnostics`, and fresh or continuing `playbook run`, and
wins over that playbook's `from` the way a `--with` fragment wins over the
file. An absolute path becomes a file URL, a relative path resolves against
the directory where you run the command, and a file URL or package specifier
is kept. The flag is never forwarded to tmux-play or sent as Boss input; it is
refused beside a raw `--config`, during uncertain-turn recovery, for an id
given twice, and for an id the config does not enable
([[playbook-cli-94](https://github.com/sublang-ai/playbook/blob/main/specs/packages/playbook-cli.md#playbook-cli-94)],
[[playbook-cli-96](https://github.com/sublang-ai/playbook/blob/main/specs/packages/playbook-cli.md#playbook-cli-96)],
[DR-083](https://github.com/sublang-ai/playbook/blob/main/specs/decisions/083-module-locations-supplied-at-launch.md)).

```sh
playbook --module code=/opt/env/code/registry.mjs
playbook run --module review=@sublang/playbook/review/registry "/review the last commit"
```

### Continuing a Captain session

Interactive and headless commands write the same logical-session records in
the configured [`sessions` directory](configuration.md#session-storage), whose
default is `${SPEX_HOME:-$HOME/.spex}/sessions/`. A fresh
interactive child persists turn zero before printing `playbook: session <id>`
and opening Boss input; a fresh headless turn returns the same kind of ID in
`--json`. After the current writer exits or explicitly hands off, either
presentation can reopen either origin:

```sh
# Reopen the newest session stored for this working directory headlessly:
playbook run --continue "keep the scope small; skip the docs"

# Reopen one exact session in either presentation:
playbook --session 4f2c0000-0000-4000-8000-000000009ab1
playbook run --session 4f2c0000-0000-4000-8000-000000009ab1
```

Bare `--continue` prefers the newest durable record whose stored working
directory equals the directory where the command is invoked. If none matches,
it reports that absence on stderr and selects the globally newest record,
naming that session and its stored working directory. Use `--session <id>` to
select one exact session without applying the directory preference. The
uncertainty rules below still apply to whichever record is selected
([DR-041](https://github.com/sublang-ai/playbook/blob/main/specs/decisions/041-working-directory-aware-continuation.md)).

A missing headless reply is read verbatim from stdin. Reopening restores the
Captain recovery journal, engagement stack, nested child boundary,
stable-player ledger, and absolute working directory without replaying a
settled or pending child start. One exclusive writer owns the session, so a
detached interactive pane child remains the owner until it shuts down; a
competing front end fails closed instead of forking the history.

An ordinary reopen reads current config and any opening `--with` fragments,
projects them to the stored catalog and player roster, and requires the stored
role bindings plus every structural setting to remain exact. A playbook whose
current config names no `from` and receives no `--module` keeps the module the
session records. Otherwise the module so taken — the supplied one, else a
present `from` — must equal the stored module; a present `from` beside a
supplied module is checked for form only. A `--module` for a playbook your
config enables but the session does not hold is ignored, while one naming no
playbook of your config is refused. Compatible current `model`, `effort`, and
optional `fastMode`, `ultracode`, `subagentModel`, and `subagentEffort` settings apply to
the next call. Boolean `false` explicitly
removes the role’s configured model, effort, subagent model, or subagent effort pin.
An omitted Claude primary model delegates to the native SDK: on resume,
`ANTHROPIC_MODEL` from the environment or native `settings.env` overrides the
session model. Changing only the top-level `model` key in Claude Code’s own `settings.json`
preserves the session selection.
A concrete model switches it. `fastMode: false` is a literal
disabled request; omission selects the provider default or inherits the player
value at a role binding.
Provider conversations are local hints. Missing hints start fresh from stored
context; a definite pre-execution rejection permits one fresh attempt.
Unsupported settings and ambiguous failures do not trigger that fallback
([[playbook-cli-22](https://github.com/sublang-ai/playbook/blob/main/specs/packages/playbook-cli.md#playbook-cli-22)],
[DR-032](https://github.com/sublang-ai/playbook/blob/main/specs/decisions/032-explicit-roles-session-players.md)).

### Following replay history

Both front ends record observed host records in order through the shared store.
A session is one schema-9 `<session-id>.json` manifest file and a replay log of
append-only segments in `<session-id>.replay/`, sealed at 1 MiB and at each
settled turn. The manifest, segments and blob parts are each at most 8 MiB.
Large values, segment lists and records can span multiple verified parts in
`<session-id>.blobs/`. Attachments keep their configured size limit. Use `readHistory()` or
`readStream()` rather than reading the segments. Logical replay still contains
version-1 envelopes with contiguous writer-assigned sequences and optional
local roles.

The hydrated manifest remains logical schema 7 and contains token-free recovery.
Replay carries immutable configuration and graph records, so history does not
require installed modules. Provider continuation hints live separately in
`<session-id>.hints.json` and stay local. A hint is consumed before use and
accepted only for the exact checkpoint that created it.

The file bound does not cap total disk usage or in-memory session size.
At settlement the writer removes blob parts that the manifest and replay no
longer reference. Sealed replay segments stay with the session.

The manifest hashes its exact durable replay prefix. Missing or changed bytes,
saved incompleteness, or unsupported required context block continuation while
preserving readable history. A partial final line waits for completion; valid
unknown record kinds are skipped for presentation. New session creation fails
if its required context cannot be saved before work.

After work begins, replay failure stops recording and reports an incomplete
history warning without authorizing a repeated action. Recovery and uncertainty
remain durable; the incomplete marker persists across process restarts.
Release retains the lease if that marker cannot be saved.

Copy the complete file inventory from `exportBundle().files`, including replay
segments, blob parts and assets. Do not copy hints or leases, or serialize the hydrated manifest
back into one large file.
Continuation also requires matching working-directory/module paths and
compatible runtimes; changed paths allow history only. Prompts, replies and
tool content remain sensitive even after structured continuation fields have
been removed. See the [shared storage contract](https://github.com/sublang-ai/playbook/blob/main/specs/packages/session-storage.md).

### Converting earlier sessions

This version reads only schema-9 sessions. Sessions saved by earlier versions —
schema 8 (`<session-id>.chunks/`) and schema 7 (`<session-id>.records.jsonl`) —
are listed as unsupported and left unchanged until you convert them. Quit every
app and host using the sessions, upgrade every device that syncs them, then run:

```sh
playbook sessions upgrade [<dir>] [--recursive] [--dry-run] [--with <path>]...
```

Without a directory it converts the configured sessions directory. With
`--recursive` it finds every directory named `sessions` under the given one,
following no link and skipping `.git`, `node_modules` and `.legacy-sessions`.
`--dry-run` lists what it would convert. Each session is verified completely,
written in schema 9 under its lease, and switched only when its logical manifest,
exact replay bytes and replay digest match; the former files then move to
`.legacy-sessions/<session-id>/` beside the sessions directory, outside sync.
Sessions already converted, in another format or in use are skipped; a stopped
run can be run again. Records older than schema 7 and desktop sidecars are not
converted: migrate them with an earlier Playbook version first.

### Reconciling possible repository effects

For each governed player call, Playbook records a Git baseline before the call
and a durable receipt afterward. CODE and DECIDE commit arms, and REVIEW's
Coder commit arm, accept a commit only when the receipt proves exactly one
descendant commit with no residual repository change; REVIEW's Reviewer calls,
DECIDE's proposal calls, every DEV Analyst planning call, BRANCH's Coder call,
and PR's Coder call require the repository to remain exact — a new branch at
the current commit, a push, and an opened pull request change neither HEAD's
commit nor the working tree, and BRANCH takes its base revision from that
receipt rather than from the Coder. PR's check waits, fix publication, merge,
and fast-forward are agent-free script steps outside governance; the merge is
the one step that moves HEAD, onto the default branch. The
player's prose, including any `Commit:` line, is presentation rather than
proof.

If interruption, missing semantic evidence, concurrent work, or an ambiguous
repository delta prevents those facts from agreeing, the workflow parks
without replaying the player. Captain reports whether a change was observed or
could not be excluded, with the available baseline, after-HEAD, and proven
commit identity but no repository paths. While parked, ask Captain either to
retry reconciliation from the retained evidence or to abandon the unresolved
attempt. Reconciliation may complete the saved evidence or restore an exact
deferred Boss-question checkpoint, but it starts no replacement player call;
abandonment disposes the complete engagement without claiming an authored
workflow outcome. The same restricted recovery survives process restart
([DR-040](https://github.com/sublang-ai/playbook/blob/main/specs/decisions/040-outcome-authority-effect-reconciliation.md)).

### Preparing a stopped step

Captain automatically tries to prepare and resume a step stopped by an operation in the current turn. You can also supply a missing answer or ask for a repair:

```sh
playbook run --session <id> "Install the missing dependency and continue."
```

This also works in the interactive Boss pane. Captain may inspect prerequisites, prepare local tools, put generated files aside, and adjust local ignore settings. It preserves user work and the task's scope. It cannot do the remaining specialist work, change saved session data, invent a result, or skip a step.

The runtime checks the continuation. It retries the interrupted step, keeps earlier commits, and uses saved output when only its assessment was interrupted. If a read-only check left unwanted files, retry requires restoring its original files and HEAD; the original failure stays recorded. A waiting player's repository checkpoint must remain intact.

Captain asks Boss for a real missing decision, uncertain permission, or a missing or contradictory playbook transition. Repository checks alone cannot prove that publishing or another outside action is safe to repeat; Captain must check that separately.

Preparation allows at most two automatic attempts, each following a stop produced by work in this turn. Resuming saved work or refusing new text does not start preparation. Each preparation has a 150-second deadline. When a turn with recorded progress throws and its calls drain safely, the latest stopped step is saved and accepts a new instruction; the interactive pane stays open. Before every player, script or preparation step, the runner saves its position; it saves the result before advancing. After process loss, Retry only restores and reports. Boss chooses what happens next. Custom hosts must provide cancellation before preparation is available.

Custom runtimes can provide the same recovery offer: step prompt, optional preparation conditions and evidence, and a continuation they will validate. Captain needs no list of repair tools or error strings. Failed checkpoints without an invocation position have no step retry; restarting the whole playbook could repeat completed work.

Captain may answer a player from the original task when it already answers the question. It reports what it reused, respects later Boss instructions and never sends that original answer twice automatically.

If a process loses the exact stopping point, retry settles the attempt in chat without repeating player work. Files and recorded evidence remain; unrelated saved workflows remain available. This also works when the attempt began from chat or used a custom runtime.

All applications sharing a session store, including Spex and the CLI, must upgrade together before running this version: every step writes the new progress fields, and every saved shell snapshot carries `presentedEffectPrefix`. Hosts through 16.0.x reject those fields as unknown, so they cannot open any session this version saves.

### Recovering an uncertain turn

Before model work, the runner takes one exclusive session lease and writes an
uncertain marker. If the process is interrupted after effects may
have begun but before settlement is durable, ordinary continuation refuses
to guess. Retry restores the saved position and reports what happened, without running any work. Discard is a separate explicit request:

```sh
playbook run --session 4f2c0000-0000-4000-8000-000000009ab1 --retry-uncertain
playbook run --session 4f2c0000-0000-4000-8000-000000009ab1 --discard-uncertain
```

Retry reads no input and restores the recorded attempt only to report it. It runs no model work. Later turns use the current compatible configuration. A completed step can use its saved result without running again. Before repeating an unfinished step, Boss must confirm that the old worker has stopped and check any outside actions; unchanged files do not prove nothing happened. A runtime that cannot save its position returns to Captain with the work preserved. Discard
reads no input and runs no model: it restores the exact prior settled boundary,
or deletes a never-settled fresh session, while abandoning the attempted work.
An interrupted interactive turn that could not save a normal pause uses the same uncertain record and these headless recovery commands. Discard preserves the attempt's replay history and
refuses if the effect ledger has advanced beyond the prior checkpoint or any step was recorded. It does not undo files or commits. Captain never selects discard automatically.

The CLI no longer imports sessions from the former
`${XDG_STATE_HOME:-$HOME/.local/state}/playbook/sessions` default; those files
stay where they are. Ordinary continuation never guesses missing identity or
effects.
